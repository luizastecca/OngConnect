export type RootStackParamList = {
    Login: undefined;
    MainTabs: { usuario: string }; // Adicione esta linha
    Dashboard: { userId: string; userName: string }; 
};

export type TabParamList = {
    Explorar: { usuario: string };
    Dashboard: { usuario: string };
    Perfil: { usuario: string };
};