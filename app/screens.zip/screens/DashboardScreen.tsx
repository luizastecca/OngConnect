
import { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useRef } from 'react';
import {
    Animated,
    Button,
    StyleSheet,
    Text,
    View
} from 'react-native';

import { CompositeScreenProps } from '@react-navigation/native';
import { RootStackParamList, TabParamList } from '../types/navigation';

type Props = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, 'Explorar'>,
  NativeStackScreenProps<RootStackParamList>
>;



export default function Home({ route, navigation }: Props) {
  const usuario = route.params?.usuario || 'Visitante';
  const fadeAnim = useRef(new Animated.Value(0)).current;


    return(
        <View>
            <Text>Bem-vindo, {usuario}!</Text>
            
            <View>
                <Button title='Voltar' color="#222b54ff" onPress={()=> navigation.goBack()}
                    /> 
                <Button title="Logout (Reset)"
                color="#92dfe5ff"
                onPress={() => navigation.reset(
                    {index: 0, routes:[{name:'Login'}]
                })}
                />

            </View>


        </View>
    )
}

const styles = StyleSheet.create({

 button: {
    backgroundColor: '#222b54ff',
    padding: 12,
    borderRadius: 20,
    marginTop: 10,
    fontSize: 17,
  },

    title: {
    fontSize: 30,
    fontWeight: '600',
    fontFamily: 'Montserrat',
    color: '#222b54ff',
  },
});