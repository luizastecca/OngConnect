import React, { useEffect, useRef } from 'react';
import {
    Animated,
    FlatList,
    StatusBar,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';

// ===== DADOS MOCKADOS DAS ONGS =====
const ONGS_DATA = [
    {
        id: '1',
        nome: 'Mãos Solidárias',
        cidade: 'São Paulo, SP',
        descricao: 'Conectamos voluntários a projetos sociais que apoiam famílias em situação de vulnerabilidade.',
        emoji: '🤝',
        cor: '#FFE8CC',
    },
    {
        id: '2',
        nome: 'Rede Esperança',
        cidade: 'Campinas, SP',
        descricao: 'ONG focada na arrecadação de alimentos, roupas e apoio comunitário.',
        emoji: '❤️',
        cor: '#E8F4E8',
    },
    {
        id: '3',
        nome: 'Comunidade Viva',
        cidade: 'Santos, SP',
        descricao: 'Promovemos ações sociais e educativas para crianças e idosos da região.',
        emoji: '🌎',
        cor: '#EDE8FF',
    },
    {
        id: '4',
        nome: 'Projeto Luz',
        cidade: 'Guarulhos, SP',
        descricao: 'Incentivamos o voluntariado e a doação para causas sociais locais.',
        emoji: '✨',
        cor: '#FFE8F0',
    },
];

export default function Ongs() {
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
        }).start();
    }, []);

    // ===== RENDERIZA CADA ONG =====
    const renderOngItem = ({ item }: { item: typeof ONGS_DATA[0] }) => (
        <TouchableOpacity
            style={[styles.card, { backgroundColor: item.cor }]}
            activeOpacity={0.9}
        >
            <View style={styles.emojiBox}>
                <Text style={styles.emoji}>{item.emoji}</Text>
            </View>

            <View style={styles.infoArea}>
                <Text style={styles.nome}>{item.nome}</Text>

                <Text style={styles.cidade}>
                    📍 {item.cidade}
                </Text>

                <Text style={styles.descricao}>
                    {item.descricao}
                </Text>
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" />

            <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
                <Text style={styles.titulo}>
                    ONGs 🏠
                </Text>

                <Text style={styles.subtitulo}>
                    Conheça as instituições sociais que estão procurando parceiros e voluntários para auxílio.
                </Text>
            </Animated.View>

            <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
                <FlatList
                    data={ONGS_DATA}
                    renderItem={renderOngItem}
                    keyExtractor={(item) => item.id}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={styles.listContent}
                />
            </Animated.View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FDF6EE',
    },

    header: {
        paddingHorizontal: 24,
        paddingTop: 24,
    },

    titulo: {
        fontSize: 28,
        fontWeight: '800',
        color: '#3D2314',
    },

    subtitulo: {
        fontSize: 14,
        color: '#7A5A4A',
        marginTop: 6,
        lineHeight: 20,
    },

    listContent: {
        padding: 24,
        paddingBottom: 40,
    },

    card: {
        borderRadius: 24,
        padding: 20,
        marginBottom: 18,

        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 10,

        elevation: 3,
    },

    emojiBox: {
        width: 70,
        height: 70,
        borderRadius: 35,
        backgroundColor: 'rgba(255,255,255,0.6)',

        justifyContent: 'center',
        alignItems: 'center',

        marginBottom: 14,
    },

    emoji: {
        fontSize: 36,
    },

    infoArea: {
        gap: 6,
    },

    nome: {
        fontSize: 22,
        fontWeight: '800',
        color: '#3D2314',
    },

    cidade: {
        fontSize: 13,
        color: '#7A5A4A',
        fontWeight: '600',
    },

    descricao: {
        fontSize: 14,
        color: '#5A3A2A',
        lineHeight: 22,
        marginTop: 4,
    },
});