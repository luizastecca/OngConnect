import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { RootStackParamList, TabParamList } from './types/navigation';

import DashboardScreen from './screens/DashboardScreen';
import ExplorarScreen from './screens/ExplorarScreen';
import LoginScreen from './screens/LoginScreen';
import PerfilScreen from './screens/PerfilScreen';

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

function TabIcon({ emoji, label, focused }: { emoji: string; label: string; focused: boolean }) {
  return (
    <View style={[tabStyles.iconWrap, focused && tabStyles.iconWrapActive]}>
      <Text style={tabStyles.emoji}>{emoji}</Text>
      {focused && <Text style={tabStyles.label}>{label}</Text>}
    </View>
  );
}

const tabStyles = StyleSheet.create({
  iconWrap: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 25, gap: 8 },
  iconWrapActive: { backgroundColor: '#3D2314' },
  emoji: { fontSize: 26 },
  label: { fontSize: 16, fontWeight: '700', color: '#FFF' },
});

function TabNavigator({ route }: any) {
  const usuario = route?.params?.usuario || 'Visitante';
  return (
    <Tab.Navigator screenOptions={{ headerShown: false, tabBarShowLabel: false, tabBarStyle: { height: Platform.OS === 'ios' ? 100 : 80 } }}>
      <Tab.Screen 
      name="Perfil" 
      component={PerfilScreen} 
      initialParams={{ usuario }} 
      options={{ tabBarIcon: ({ focused }) => 
      <TabIcon emoji="👤" label="Perfil" focused={focused} /> }} />
       <Tab.Screen 
       name="Explorar" 
       component={ExplorarScreen} initialParams={{ usuario }} 
       options={{ tabBarIcon: ({ focused }) => 
       <TabIcon emoji="🔍" label="Explorar" focused={focused} /> }} />
      <Tab.Screen 
      name="Dashboard" 
      component={DashboardScreen} 
      initialParams={{ usuario }} 
      options={{tabBarIcon: ({ focused }) => 
      <TabIcon emoji="🚹" label="Dashboard" focused={focused} /> }} />
    </Tab.Navigator>
  );
}

export default function App(){
  return(

    <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
      <Stack.Screen
      name = "Login"
      component ={LoginScreen}
      options={{ title: 'Acesso', headerShown: false}}
      />

       <Stack.Screen
      name = "Dashboard"
      component ={DashboardScreen}
      options={{ title: 'Acesso', headerShown: false}}
      />

       <Stack.Screen
      name = "Explorar"
      component ={ExplorarScreen}
      options={{ title: 'Acesso', headerShown: false}}
      />

      <Stack.Screen
      name = "Perfil"
      component ={PerfilScreen}
      options={{ title: 'Acesso', headerShown: false}}
      />

     

    </Stack.Navigator>

  );
}
